// =====================================================================
// server.js - the "kitchen".
// The webpage (public/index.html) asks this server; this server asks
// Spotify and Gemini. If either fails, we FALL BACK to sample data or a
// backup roast, so the demo NEVER shows an error screen.
// =====================================================================
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const express = require('express');

// ---------- load keys ----------
// Looks for ".env" first, then "_env", then "env.txt" (so a wrongly named
// file still works). Uses the first one it finds.
const envFile = ['.env', '_env', 'env.txt']
  .map(f => path.join(__dirname, f))
  .find(p => fs.existsSync(p));
if (envFile) {
  dotenv.config({ path: envFile });
  console.log('Keys loaded from:', path.basename(envFile));
} else {
  console.warn('WARNING: no .env file found. Sample data + backup roasts will be used.');
}

const app = express();
app.use(express.json());
// __dirname = works no matter which folder you start node from
app.use(express.static(path.join(__dirname, 'public')));

const PORT = 3000;
// This EXACT text must be added in the Spotify dashboard -> Redirect URIs
const REDIRECT_URI = `http://127.0.0.1:${PORT}/callback`;

// Removes accidental spaces / quotes around values in the env file
const clean = v => (v || '').trim().replace(/^["']|["']$/g, '');

const GEMINI_API_KEY = clean(process.env.GEMINI_API_KEY);
const SPOTIFY_CLIENT_ID = clean(process.env.SPOTIFY_CLIENT_ID);
const SPOTIFY_CLIENT_SECRET = clean(process.env.SPOTIFY_CLIENT_SECRET);

// GEMINI FIX: instead of ONE model, we try a list. If a model is
// overloaded (503), out of quota (429) or not found (404), the server
// moves to the next one automatically. You can put your own first choice
// in the env file as GEMINI_MODEL=...
const GEMINI_MODELS = [
  clean(process.env.GEMINI_MODEL),
  'gemini-3.7-flash',
  'gemini-3.8-flash',
  'gemini-2.5-flash',
].filter((m, i, arr) => m && arr.indexOf(m) === i); // remove empty + duplicates

if (!GEMINI_API_KEY) console.warn('WARNING: GEMINI_API_KEY missing -> backup roasts will be used.');
if (!SPOTIFY_CLIENT_ID || !SPOTIFY_CLIENT_SECRET) console.warn('WARNING: Spotify keys missing -> sample data will be used.');

// One shared login for the whole demo (fine for a single-laptop demo)
let accessToken = null;
let tokenExpiresAt = 0;
const tokenIsValid = () => !!accessToken && Date.now() < tokenExpiresAt;

// =====================================================================
// SAMPLE DATA - used when Spotify login fails for ANY reason.
// Each call gives the next set, so repeated demos don't look identical.
// =====================================================================
const SAMPLE_SETS = [
  {
    tracks: [
      ['Kesariya', 'Arijit Singh'], ['Tum Hi Ho', 'Arijit Singh'],
      ['Raataan Lambiyan', 'Jubin Nautiyal'], ['Channa Mereya', 'Arijit Singh'],
      ['Apna Bana Le', 'Arijit Singh'], ['Kaise Hua', 'Vishal Mishra'],
      ['Pehle Bhi Main', 'Vishal Mishra'], ['Heeriye', 'Jasleen Royal'],
      ['O Bedardeya', 'Arijit Singh'], ['Tere Vaaste', 'Varun Jain'],
    ],
    artists: ['Arijit Singh', 'Jubin Nautiyal', 'Vishal Mishra', 'Jasleen Royal', 'Pritam'],
  },
  {
    tracks: [
      ['Excuses', 'AP Dhillon'], ['Brown Munde', 'AP Dhillon'],
      ['Softly', 'Karan Aujla'], ['295', 'Sidhu Moose Wala'],
      ['Lover', 'Diljit Dosanjh'], ['Cheques', 'Shubh'],
      ['Elevated', 'Shubh'], ['Insane', 'AP Dhillon'],
      ['Baller', 'Shubh'], ['Winning Speech', 'Karan Aujla'],
    ],
    artists: ['AP Dhillon', 'Shubh', 'Karan Aujla', 'Diljit Dosanjh', 'Sidhu Moose Wala'],
  },
  {
    tracks: [
      ['Kal Ho Naa Ho', 'Sonu Nigam'], ['Tum Se Hi', 'Mohit Chauhan'],
      ['Ilahi', 'Arijit Singh'], ['Kabira', 'Tochi Raina'],
      ['Kun Faya Kun', 'A.R. Rahman'], ['Phir Le Aya Dil', 'Arijit Singh'],
      ['Tera Ban Jaunga', 'Akhil Sachdeva'], ['Iktara', 'Kavita Seth'],
      ['Tujhe Kitna Chahne Lage', 'Arijit Singh'], ['Agar Tum Saath Ho', 'Alka Yagnik'],
    ],
    artists: ['A.R. Rahman', 'Arijit Singh', 'Pritam', 'Mohit Chauhan', 'Sonu Nigam'],
  },
];
let sampleIndex = 0;

function getSampleData() {
  const s = SAMPLE_SETS[sampleIndex % SAMPLE_SETS.length];
  sampleIndex++;
  return {
    tracks: s.tracks.map(([name, artist]) => ({ name, artist })),
    artists: s.artists,
  };
}

// "Use sample data" button calls this
app.get('/api/sample-data', (req, res) => {
  res.json({ ...getSampleData(), source: 'sample' });
});

// =====================================================================
// CHECK PAGES (for you to verify everything in 10 seconds)
//  /api/status       -> are the keys loaded? (shows true/false only)
//  /api/test-gemini  -> does Gemini really answer? which model worked?
// =====================================================================
app.get('/api/status', (req, res) => {
  res.json({
    envFileFound: envFile ? path.basename(envFile) : false,
    geminiKeyLoaded: !!GEMINI_API_KEY,
    geminiModelsTried: GEMINI_MODELS,
    spotifyClientIdLoaded: !!SPOTIFY_CLIENT_ID,
    spotifyClientSecretLoaded: !!SPOTIFY_CLIENT_SECRET,
    spotifyLoggedIn: tokenIsValid(),
    redirectUriToAddInSpotifyDashboard: REDIRECT_URI,
    roastsGeneratedThisSession: usedRoasts.length,
  });
});

app.get('/api/test-gemini', async (req, res) => {
  if (!GEMINI_API_KEY) return res.json({ ok: false, problem: 'GEMINI_API_KEY not loaded from env file' });
  const out = await callGemini('Reply with JSON: {"ok":true}');
  if (out) return res.json({ ok: true, modelThatWorked: out.model });
  res.json({ ok: false, problem: 'Gemini failed on all models. Read the red messages in the terminal.' });
});

// =====================================================================
// SPOTIFY LOGIN
// Any failure redirects to /?connected=1&fallback=1 so the page goes on
// with SAMPLE data instead of showing an error.
// =====================================================================
app.get('/login', (req, res) => {
  if (!SPOTIFY_CLIENT_ID || !SPOTIFY_CLIENT_SECRET) {
    console.error('Spotify keys missing -> using sample data');
    return res.redirect('/?connected=1&fallback=1');
  }

  const params = new URLSearchParams({
    response_type: 'code',
    client_id: SPOTIFY_CLIENT_ID,
    scope: 'user-top-read',
    redirect_uri: REDIRECT_URI,
    show_dialog: 'true', // always ask which account -> easy to use the friend's account
  });

  res.redirect('https://accounts.spotify.com/authorize?' + params);
});

app.get('/callback', async (req, res) => {
  const { code, error } = req.query;

  // User pressed "Cancel" on Spotify, or Spotify sent an error
  if (error || !code) {
    console.error('Spotify login not completed:', error || 'no code received');
    return res.redirect('/?connected=1&fallback=1');
  }

  try {
    const r = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization:
          'Basic ' + Buffer.from(SPOTIFY_CLIENT_ID + ':' + SPOTIFY_CLIENT_SECRET).toString('base64'),
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: REDIRECT_URI,
      }),
      signal: AbortSignal.timeout(10000), // never hang forever
    });

    const data = await r.json();

    // Check the login really worked before saying "connected"
    if (!r.ok || !data.access_token) {
      console.error('Spotify token exchange failed:', r.status, data);
      return res.redirect('/?connected=1&fallback=1');
    }

    accessToken = data.access_token;
    // Spotify tokens last ~1 hour; expire 1 minute early to be safe
    tokenExpiresAt = Date.now() + (data.expires_in || 3600) * 1000 - 60000;

    res.redirect('/?connected=1');
  } catch (e) {
    console.error('Callback error:', e.message);
    res.redirect('/?connected=1&fallback=1');
  }
});

// =====================================================================
// SPOTIFY DATA - always returns usable data: real, or sample as backup.
// "source" says which one it was ("spotify" or "sample").
// =====================================================================
async function getTop(type, limit, range) {
  const r = await fetch(
    `https://api.spotify.com/v1/me/top/${type}?limit=${limit}&time_range=${range}`,
    { headers: { Authorization: 'Bearer ' + accessToken }, signal: AbortSignal.timeout(10000) }
  );
  const body = await r.json().catch(() => ({}));
  console.log(`Spotify top ${type} (${range}) status:`, r.status);
  if (!r.ok) console.error('Spotify said:', JSON.stringify(body));
  return { ok: r.ok, status: r.status, items: body.items || [] };
}

app.get('/api/spotify-data', async (req, res) => {
  const useSample = reason => {
    console.warn('Using SAMPLE data because:', reason);
    res.json({ ...getSampleData(), source: 'sample', reason });
  };

  if (!tokenIsValid()) return useSample('not logged in or login expired');

  try {
    let t = await getTop('tracks', 10, 'short_term');
    let a = await getTop('artists', 5, 'short_term');

    // New / quiet accounts may have no last-4-weeks history -> try last 6 months
    if (t.ok && t.items.length === 0) {
      t = await getTop('tracks', 10, 'medium_term');
      a = await getTop('artists', 5, 'medium_term');
    }

    // 403 here = Spotify dashboard setup problem (owner needs Premium, or the
    // logged-in email is not added under "User Management"), not a code bug.
    if (!t.ok) return useSample(`spotify returned ${t.status}`);
    if (t.items.length === 0) return useSample('account has no listening history');

    res.json({
      tracks: t.items.map(x => ({
        name: x.name,
        artist: x.artists?.[0]?.name || 'Unknown artist',
      })),
      artists: a.ok ? a.items.map(x => x.name) : [],
      source: 'spotify',
    });
  } catch (e) {
    console.error('Spotify data error:', e.message);
    useSample('spotify request failed');
  }
});

// =====================================================================
// AI ROAST - different every time (also on "Roast me again" and when
// switching between Friendly and Savage).
// How uniqueness is guaranteed:
//  1. every roast gets a different random "angle" (theme)
//  2. Gemini is shown the latest roasts and told not to repeat them
//  3. the server compares each result with ALL earlier roasts (exact and
//     near-duplicate). Repeat -> it asks again with a new angle
//  4. if Gemini is down or keeps repeating -> a backup roast is built
//     from the person's own songs, again checked for uniqueness
// =====================================================================
const usedRoasts = [];        // normalised text of every roast sent
const recentRoastTexts = [];  // original text of the latest ones (shown to Gemini)

const norm = s =>
  String(s || '').toLowerCase().replace(/[^a-z0-9\u0900-\u097f ]/g, '').replace(/\s+/g, ' ').trim();

// true if the roast is identical, or shares ~60% of its words with an earlier one
function isRepeat(text) {
  const n = norm(text);
  if (!n) return true;
  const words = new Set(n.split(' '));
  for (const u of usedRoasts) {
    if (u === n) return true;
    const uw = new Set(u.split(' '));
    let common = 0;
    for (const w of words) if (uw.has(w)) common++;
    if (common / (words.size + uw.size - common) > 0.6) return true;
  }
  return false;
}

function remember(text) {
  usedRoasts.push(norm(text));
  recentRoastTexts.push(text);
  if (usedRoasts.length > 300) usedRoasts.shift();
  if (recentRoastTexts.length > 8) recentRoastTexts.shift();
}

const ANGLES = [
  'their playlist is a Bollywood breakup that never ended',
  'overthinking at 2 AM instead of sleeping',
  'a nosy Indian relative reviewing their taste at a family function',
  'placement season stress hidden behind emotional songs',
  'hostel-room life and unpaid Wi-Fi',
  'an auto-rickshaw uncle judging their playlist',
  'a cricket commentator narrating their listening habits',
  'a wedding DJ reacting to their taste',
  'a crush who left them on read',
  "Sharma ji's son having a very different playlist",
  'exam-week procrastination',
  'a Mumbai local train commute with only one song',
  'a therapist who has heard this playlist too many times',
  'a Bollywood movie monologue about their song choices',
];
let angleDeck = [];
function nextAngle() {
  if (angleDeck.length === 0) angleDeck = [...ANGLES].sort(() => Math.random() - 0.5); // reshuffle
  return angleDeck.pop();
}

const pick = arr => arr[Math.floor(Math.random() * arr.length)];

// ---------- backup roasts (used only if Gemini fails) ----------
// SAVAGE ones are funny-mean, FRIENDLY ones are gentle teasing.
const BACKUP_SAVAGE = [
  c => `${c.song} on repeat again? Even your earphones have asked for a transfer. ${c.artist} should be paying you rent by now.`,
  c => `Your ${c.score}/100 obsession score says you did not find ${c.song}, you got trapped in it. ${c.artist} has become your emotional support human.`,
  c => `Playing ${c.song} on repeat will not make them text back. ${c.artist} cannot fix this one.`,
  c => `You call it a playlist, the neighbours call it a cry for help. ${c.song} is not a personality, yet here we are.`,
  c => `${c.artist} released a whole discography and you chose to live inside ${c.song}. Commitment issues? Only with new music.`,
  c => `Somewhere ${c.artist} is being streamed by you at 3 AM. ${c.song} knows your secrets and is tired of them.`,
  c => `Your Wrapped will just say "${c.song}" a thousand times and a doctor's note. Explore one artist besides ${c.artist}, please.`,
  c => `${c.song} is not a song for you, it is a lifestyle. Even Sharma ji's son would say "bro, skip once".`,
  c => `You have ${c.score}% obsession and 0% shame. ${c.artist}'s ${c.song} is basically your relationship status.`,
  c => `Bold of you to let ${c.song} carry your whole mood. ${c.artist} deserves a day off, and so do your neighbours.`,
  c => `Your taste is 90% ${c.artist} and 10% pretending you are not sad. ${c.song} gave you away.`,
  c => `Every playlist has a hero. Yours is ${c.song}, and it has been working overtime since forever.`,
];

const BACKUP_FRIENDLY = [
  c => `${c.song} again? We get it, it is a great song. ${c.artist} is lucky to have such a loyal fan.`,
  c => `A ${c.score}/100 obsession score means you love hard, and ${c.song} knows it. Maybe let ${c.artist} rest for five minutes?`,
  c => `You and ${c.song} have a beautiful long-term relationship. Just remember other songs exist too, they are shy.`,
  c => `Your playlist is basically a diary and ${c.artist} is the co-author. ${c.song} is definitely the favourite chapter.`,
  c => `Only a true fan plays ${c.song} this many times. ${c.artist} would be proud, and slightly worried.`,
  c => `You are not repeating songs, you are just very loyal. ${c.song} is lucky to be your comfort zone.`,
  c => `${c.song} is clearly your happy place. Please introduce it to a new song or two, they might become friends.`,
  c => `Your music taste says you feel everything deeply, mostly through ${c.artist}. ${c.song} is doing great work.`,
  c => `That ${c.score}% obsession is adorable. ${c.song} is not just a song for you, it is a warm hug on repeat.`,
  c => `If loyalty had a playlist it would be yours: ${c.song} first, ${c.artist} forever, everything else waits.`,
  c => `You found ${c.song} and said "this is the one", and honestly, fair. ${c.artist} has great taste in fans.`,
  c => `Your headphones know you very well: ${c.song}, then ${c.song}, then a quick ${c.artist} break. Wholesome and slightly dramatic.`,
];

const BACKUP_TRAITS = [
  'Romantic', 'Overthinker', 'Just one more song', 'Midnight philosopher', 'Heartbreak veteran',
  'Main character', 'Playlist hoarder', 'Volume maxxer', 'Emotional damage', 'Sad hours regular',
  'Headphone hermit', 'Shower singer',
];

function backupPersonality() {
  const labels = [...BACKUP_TRAITS].sort(() => Math.random() - 0.5).slice(0, 3);
  return labels.map(label => ({ label, percent: 40 + Math.floor(Math.random() * 56) }));
}

function backupRoast(tracks, artists, score, mode) {
  const templates = mode === 'friendly' ? BACKUP_FRIENDLY : BACKUP_SAVAGE;
  // try random song/template combinations until we hit one nobody has seen
  for (let i = 0; i < 80; i++) {
    const t = pick(tracks);
    const c = { song: t.name, artist: t.artist || artists[0] || 'your favourite artist', score };
    const text = pick(templates)(c);
    if (!isRepeat(text)) return text;
  }
  // extreme last resort: guaranteed unique by adding a running number
  return `${pick(templates)({ song: tracks[0].name, artist: tracks[0].artist || 'your favourite artist', score })} (Roast #${usedRoasts.length + 1})`;
}

// ---------- Gemini ----------
// Tries each model in GEMINI_MODELS. For each model:
//   503 / 429 / 500 / network problem -> wait and retry (max 2 tries)
//   404 (model not found)             -> next model
//   400 / 401 / 403 (bad key etc.)    -> stop, no model will work
// Returns { text, model } or null.
async function callGemini(prompt) {
  for (const model of GEMINI_MODELS) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

    for (let attempt = 1; attempt <= 2; attempt++) {
      let retry = false;
      try {
        const r = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { responseMimeType: 'application/json' },
          }),
          signal: AbortSignal.timeout(15000), // never hang the demo
        });

        if (r.ok) {
          const data = await r.json();
          const text = (data.candidates?.[0]?.content?.parts || [])
            .filter(p => !p.thought)
            .map(p => p.text || '')
            .join('');
          if (text) return { text, model };
          console.error(`Gemini (${model}) returned no text:`, JSON.stringify(data).slice(0, 400));
          break; // try next model
        }

        const errText = await r.text();
        console.error(`Gemini (${model}) attempt ${attempt} failed [${r.status}]:`, errText.slice(0, 400));

        if ([400, 401, 403].includes(r.status)) {
          console.error('>>> Gemini key problem. Check GEMINI_API_KEY in your env file (no spaces, correct key).');
          return null; // every model would fail the same way
        }
        retry = [429, 500, 503].includes(r.status);
      } catch (e) {
        console.error(`Gemini (${model}) attempt ${attempt} error:`, e.message);
        retry = true; // network hiccup / timeout
      }

      if (!retry) break; // e.g. 404 -> go to next model
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1200));
    }
  }
  return null;
}

// Turns Gemini's text into { roast, personality } or null if unusable
function parseRoast(text) {
  const stripped = text.replace(/```json|```/g, '').trim();
  let obj;
  try {
    obj = JSON.parse(stripped);
  } catch {
    const m = stripped.match(/\{[\s\S]*\}/); // grab the {...} part if extra text sneaked in
    if (!m) return null;
    try { obj = JSON.parse(m[0]); } catch { return null; }
  }
  if (!obj || typeof obj.roast !== 'string' || !obj.roast.trim()) return null;

  let personality = Array.isArray(obj.personality)
    ? obj.personality
        .filter(p => p && p.label)
        .map(p => ({
          label: String(p.label),
          percent: Math.max(0, Math.min(100, Math.round(Number(p.percent) || 0))),
        }))
        .slice(0, 3)
    : [];
  if (personality.length < 3) personality = backupPersonality(); // never send a broken bar list

  return { roast: obj.roast.trim(), personality };
}

app.post('/api/roast', async (req, res) => {
  // ---- read + clean input ----
  const body = req.body || {};
  let tracks = Array.isArray(body.tracks)
    ? body.tracks.filter(t => t && t.name).map(t => ({ name: String(t.name), artist: String(t.artist || '') })).slice(0, 10)
    : [];
  let artists = Array.isArray(body.artists) ? body.artists.filter(Boolean).map(String).slice(0, 5) : [];
  const score = Number.isFinite(Number(body.score)) ? Math.round(Number(body.score)) : 50;
  const mode = body.mode === 'friendly' ? 'friendly' : 'savage';

  if (tracks.length === 0) {
    const s = getSampleData();
    tracks = s.tracks;
    artists = s.artists;
  }

  const tone =
    mode === 'friendly'
      ? 'playful and kind, like a friend teasing gently. No insults, keep it warm and wholesome'
      : 'savage but funny, like a stand-up comedian';

  // ---- try Gemini (2nd round only if the 1st result was a repeat/unusable) ----
  if (GEMINI_API_KEY) {
    for (let round = 1; round <= 2; round++) {
      const angle = nextAngle();
      const avoid = recentRoastTexts.length
        ? `\nYou already used these roasts. Do NOT repeat their jokes, structure or wording:\n- ${recentRoastTexts.join('\n- ')}\n`
        : '';

      const prompt = `You are a funny Indian music critic. Tone: ${tone}.
Roast this person in exactly 2 short lines based on their music.
Creative angle for THIS roast: ${angle}.
Mention at least one of their songs or artists by name. No repeated jokes.${avoid}
Top songs: ${tracks.map(t => t.name + (t.artist ? ' by ' + t.artist : '')).join(', ')}.
Top artists: ${artists.join(', ')}.
Their "Obsession Score" is ${score}/100.
Also give 3 personality traits with percentages (they do not need to add up to 100). Invent 3 fresh 1-3 word labels that fit this person; do not reuse generic ones.
Reply ONLY with JSON in exactly this shape:
{"roast":"line one. line two.","personality":[{"label":"trait","percent":70},{"label":"trait","percent":60},{"label":"trait","percent":85}]}`;

      const out = await callGemini(prompt);
      if (!out) break; // Gemini is down -> go to backup roast

      const parsed = parseRoast(out.text);
      if (!parsed) { console.error('Gemini gave unusable JSON:', out.text.slice(0, 300)); continue; }

      if (isRepeat(parsed.roast)) {
        console.warn('Gemini repeated a roast, asking again with a new angle');
        continue;
      }

      remember(parsed.roast);
      return res.json({ ...parsed, source: 'ai' });
    }
  }

  // ---- backup roast: still unique, still uses their real songs ----
  const roast = backupRoast(tracks, artists, score, mode);
  remember(roast);
  res.json({ roast, personality: backupPersonality(), source: 'backup' });
});

// Any unexpected crash returns JSON instead of an ugly HTML error page
app.use((err, req, res, next) => {
  console.error('Unexpected error:', err.message);
  res.status(500).json({ error: true });
});

// =====================================================================
app.listen(PORT, () => console.log(`Open http://127.0.0.1:${PORT}`));
