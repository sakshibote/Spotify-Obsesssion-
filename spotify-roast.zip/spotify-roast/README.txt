SPOTIFY OBSESSION ROAST - SETUP (about 5 minutes)

1. Install Node.js (LTS) from nodejs.org, and VS Code.
2. Unzip this folder, open it in VS Code, open the Terminal (Ctrl + `).
3. KEYS: make a file named  .env  in this folder (with the dot) and paste the
   3 lines from env-template.txt with your real keys.
   Shortcut: your old file named "_env" also works - just copy it into this
   folder, no renaming needed.
4. In the Terminal type:   npm install
5. Then type:              npm start
6. Open  http://127.0.0.1:3000  in Chrome  (use 127.0.0.1, NOT localhost).

QUICK CHECKS (open these in Chrome while the server runs)
- http://127.0.0.1:3000/api/status       -> all key fields should say true
- http://127.0.0.1:3000/api/test-gemini  -> should say "ok": true

DEMO
- "Use sample data" always works (no Spotify needed).
- "Connect with Spotify": if login or Spotify fails for ANY reason, the app
  automatically shows sample data with a small yellow note.
- "Roast me again" and the Friendly / Savage switch always give a NEW roast.

FOR REAL SPOTIFY LOGIN (Spotify dashboard, developer.spotify.com/dashboard)
- The Spotify app must be created by the account that has Premium (friend).
- Add  http://127.0.0.1:3000/callback  under Redirect URIs (exactly).
- Under User Management add the email of the Spotify account that will log in.
