@echo off
title Spotify Roast - public link
cd /d "%~dp0"

echo.
echo ===== Spotify Roast: creating your public link =====
echo.

where cloudflared >nul 2>&1
if errorlevel 1 (
  echo First time only: installing the link tool...
  winget install --id Cloudflare.cloudflared -e --accept-source-agreements --accept-package-agreements
  echo.
  echo DONE. Now CLOSE this window and double-click start-public.bat AGAIN.
  pause
  exit /b
)

REM stop any old copy of the server so port 3000 is free
taskkill /F /IM node.exe >nul 2>&1

REM start the project in its own window
start "Roast Server (keep open)" cmd /k npm start

echo Waiting for the server to start...
timeout /t 5 /nobreak >nul

echo.
echo ================================================================
echo  Look for the line with  https://something.trycloudflare.com
echo  below. THAT is your public link. Share it with anyone.
echo  Keep BOTH windows open while people are using it.
echo ================================================================
echo.
cloudflared tunnel --url http://127.0.0.1:3000
pause
